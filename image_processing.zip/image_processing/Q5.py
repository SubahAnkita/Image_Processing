# Write a program for resizing the image using inbuilt commands and without
# using inbuilt commands.
from PIL import Image
import numpy as np

# Specify the image path
image_path = r"C:\Users\tahia\OneDrive\Pictures\original.png"

# Read the image
image = Image.open(image_path)

# Using inbuilt command to resize the image
resized_image_inbuilt = image.resize((500, 500))

# Without using inbuilt command to resize the image
width, height = image.size
new_width, new_height = 500, 500

# Calculate the scaling factors
width_ratio = new_width / width
height_ratio = new_height / height

# Create a new blank image with the desired size
resized_image = Image.new("RGB", (new_width, new_height))

# Iterate over each pixel in the new image
for x in range(new_width):
    for y in range(new_height):
        # Calculate the corresponding coordinates in the original image
        src_x = int(x / width_ratio)
        src_y = int(y / height_ratio)

        # Get the pixel value from the original image
        pixel = image.getpixel((src_x, src_y))

        # Set the pixel value in the new image
        resized_image.putpixel((x, y), pixel)

# Display the resized images
resized_image_inbuilt.show()
resized_image.show()
