import cv2
import numpy as np

# Specify the image path
image_path = r"C:\Users\tahia\OneDrive\Pictures\original.png"

# Read the image
image = cv2.imread(image_path)

# Apply median filter
median_filtered_image = cv2.medianBlur(image, ksize=3)  # Adjust the kernel size as needed

# Display the original and median filtered images
cv2.imshow("Original Image", image)
cv2.imshow("Median Filtered Image", median_filtered_image)
cv2.waitKey(0)
cv2.destroyAllWindows()
