# 10. Write a program to eliminate the high frequency component of an image.

import cv2
from PIL import Image
import numpy as np

# Specify the image path
image_path = r"C:\Users\tahia\OneDrive\Pictures\original.png"

# Read the image
image = cv2.imread(image_path)

# Convert the image to grayscale
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Perform the Discrete Fourier Transform (DFT)
dft = cv2.dft(np.float32(gray_image), flags=cv2.DFT_COMPLEX_OUTPUT)
dft_shift = np.fft.fftshift(dft)

# Define the radius of the low-pass filter
radius = 30

# Create a mask to eliminate high-frequency components
rows, cols = gray_image.shape
crow, ccol = rows // 2, cols // 2
mask = np.zeros((rows, cols, 2), np.uint8)
mask[crow - radius: crow + radius, ccol - radius: ccol + radius] = 1

# Apply the mask to the frequency domain representation
filtered_shift = dft_shift * mask

# Perform the inverse Discrete Fourier Transform (IDFT)
filtered_dft = np.fft.ifftshift(filtered_shift)
filtered_image = cv2.idft(filtered_dft)
filtered_image = cv2.magnitude(filtered_image[:, :, 0], filtered_image[:, :, 1])

# Display the original and filtered images
cv2.imshow("Original Image", gray_image)
cv2.imshow("Filtered Image", filtered_image.astype(np.uint8))
cv2.waitKey(0)
cv2.destroyAllWindows()
