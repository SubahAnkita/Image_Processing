import numpy as np
import matplotlib.pyplot as plt
from PIL import Image

# Specify the image path
image_path = r"C:\Users\tahia\OneDrive\Pictures\original.png"

# Read the grayscale image
gray_image = Image.open(image_path).convert("L")

# Convert the image to a NumPy array
gray_array = np.array(gray_image)

# Calculate the histogram
histogram, bins = np.histogram(gray_array.flatten(), bins=256, range=[0, 256])

# Calculate the cumulative distribution function (CDF)
cdf = histogram.cumsum()
cdf_normalized = cdf * histogram.max() / cdf.max()

# Perform histogram equalization
equalized_array = np.interp(gray_array.flatten(), bins[:-1], cdf_normalized).reshape(gray_array.shape)
equalized_image = Image.fromarray(equalized_array.astype(np.uint8))

# Display the original and equalized images
fig, axes = plt.subplots(1, 2, figsize=(10, 5))
axes[0].imshow(gray_image, cmap='gray')
axes[0].set_title("Original Image")
axes[0].axis('off')
axes[1].imshow(equalized_image, cmap='gray')
axes[1].set_title("Equalized Image")
axes[1].axis('off')
plt.show()
