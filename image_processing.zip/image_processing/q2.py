# 2. Write a program to find the histogram value and display the histogram of a
# grayscale and color image.
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image

# Specify the image path
image_path = r"C:\Users\tahia\OneDrive\Pictures\original.png"

# Read the grayscale image
gray_image = Image.open(image_path).convert("L")

# Calculate and plot histogram for grayscale image
gray_histogram, gray_bins = np.histogram(gray_image, bins=256, range=[0, 256])
plt.figure()
plt.title("Grayscale Image Histogram")
plt.xlabel("Pixel Value")
plt.ylabel("Frequency")
plt.plot(gray_bins[:-1], gray_histogram, color='black')
plt.show()

# Read the color image
color_image = Image.open(image_path)

# Split the color image into RGB channels
red_channel, green_channel, blue_channel = color_image.split()

# Calculate and plot histograms for each RGB channel
red_histogram, red_bins = np.histogram(red_channel, bins=256, range=[0, 256])
green_histogram, green_bins = np.histogram(green_channel, bins=256, range=[0, 256])
blue_histogram, blue_bins = np.histogram(blue_channel, bins=256, range=[0, 256])

plt.figure()
plt.title("Color Image Histogram")
plt.xlabel("Pixel Value")
plt.ylabel("Frequency")
plt.plot(red_bins[:-1], red_histogram, color='red', label='Red')
plt.plot(green_bins[:-1], green_histogram, color='green', label='Green')
plt.plot(blue_bins[:-1], blue_histogram, color='blue', label='Blue')
plt.legend()
plt.show()
