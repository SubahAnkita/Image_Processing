# 7. Write a program to remove Salt and Pepper noise using median filter.


import cv2
from PIL import Image

# Specify the image path
image_path = r"C:\Users\tahia\OneDrive\Pictures\original.png"

# Read the image
image = cv2.imread(image_path)

# Convert the image to grayscale
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Apply median filter to remove salt and pepper noise
filtered_image = cv2.medianBlur(gray_image, 3)

# Display the original and filtered images
cv2.imshow("Original Image", gray_image)
cv2.imshow("Filtered Image", filtered_image)
cv2.waitKey(0)
cv2.destroyAllWindows()
