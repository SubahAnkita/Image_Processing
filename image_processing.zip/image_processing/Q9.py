# 9. Write a program to perform edge detection using different operators.

import cv2
from PIL import Image
import numpy as np

# Specify the image path
image_path = r"C:\Users\tahia\OneDrive\Pictures\original.png"

# Read the image
image = cv2.imread(image_path)

# Convert the image to grayscale
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Apply Sobel edge detection
sobel_x = cv2.Sobel(gray_image, cv2.CV_64F, 1, 0, ksize=3)
sobel_y = cv2.Sobel(gray_image, cv2.CV_64F, 0, 1, ksize=3)
sobel_edges = cv2.magnitude(sobel_x, sobel_y)

# Apply Scharr edge detection
scharr_x = cv2.Scharr(gray_image, cv2.CV_64F, 1, 0)
scharr_y = cv2.Scharr(gray_image, cv2.CV_64F, 0, 1)
scharr_edges = cv2.magnitude(scharr_x, scharr_y)

# Apply Laplacian edge detection
laplacian_edges = cv2.Laplacian(gray_image, cv2.CV_64F)

# Display the original and detected edges
cv2.imshow("Original Image", gray_image)
cv2.imshow("Sobel Edges", sobel_edges.astype(np.uint8))
cv2.imshow("Scharr Edges", scharr_edges.astype(np.uint8))
cv2.imshow("Laplacian Edges", laplacian_edges.astype(np.uint8))
cv2.waitKey(0)
cv2.destroyAllWindows()
