from PIL import Image

# Specify the image path
image_path = r"C:\Users\tahia\OneDrive\Pictures\original.png"

# Read the image
image = Image.open(image_path).convert("L")  # Convert to grayscale

# Display the image
image.show()
