import cv2
import matplotlib.pyplot as plt

def perform_edge_detection(image_path):
    # Load the image
    image = cv2.imread(image_path, 0)  # Read the image in grayscale

    # Apply Gaussian blur to reduce noise
    blurred = cv2.GaussianBlur(image, (5, 5), 0)

    # Apply Canny edge detection
    edges = cv2.Canny(blurred, 100, 200)  # You can adjust the threshold values

    # Display the original image and the edges using Matplotlib
    plt.subplot(1, 2, 1)
    plt.imshow(image, cmap='gray')
    plt.title('Original Image')
    plt.axis('off')

    plt.subplot(1, 2, 2)
    plt.imshow(edges, cmap='gray')
    plt.title('Edges')
    plt.axis('off')

    plt.show()

# Example usage
image_path = r"C:\Users\tahia\OneDrive\Pictures\original.png"
perform_edge_detection(image_path)
