# 11. Write a program to discretize an image using Fourier transform.


import cv2
from PIL import Image
import numpy as np

# Specify the image path
image_path = r"C:\Users\tahia\OneDrive\Pictures\original.png"

# Read the image
image = cv2.imread(image_path)

# Convert the image to grayscale
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Perform the Discrete Fourier Transform (DFT)
dft = cv2.dft(np.float32(gray_image), flags=cv2.DFT_COMPLEX_OUTPUT)
dft_shift = np.fft.fftshift(dft)

# Apply the inverse Discrete Fourier Transform (IDFT)
discretized_dft = np.fft.ifftshift(dft_shift)
discretized_image = cv2.idft(discretized_dft)
discretized_image = cv2.magnitude(discretized_image[:, :, 0], discretized_image[:, :, 1])

# Normalize the discretized image
discretized_image = cv2.normalize(discretized_image, None, 0, 255, cv2.NORM_MINMAX)

# Convert the image to uint8 format
discretized_image = discretized_image.astype(np.uint8)

# Display the original and discretized images
cv2.imshow("Original Image", gray_image)
cv2.imshow("Discretized Image", discretized_image)
cv2.waitKey(0)
cv2.destroyAllWindows()
