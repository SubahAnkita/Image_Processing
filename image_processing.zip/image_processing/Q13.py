# 13. Write a program to segment an image using polynomial curve fitting.
import cv2
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt

# Specify the image path
image_path = r"C:\Users\tahia\OneDrive\Pictures\original.png"

# Read the image
image = cv2.imread(image_path)

# Convert the image to grayscale
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Apply polynomial curve fitting
x = np.arange(gray_image.shape[1])
y = np.mean(gray_image, axis=0)  # Average intensity along each column
degree = 3  # Degree of the polynomial curve
coefficients = np.polyfit(x, y, degree)
curve = np.polyval(coefficients, x)

# Compute the threshold based on the curve
threshold = np.mean(curve)

# Segment the image based on the threshold
segmented_image = gray_image > threshold

# Display the original image, curve, and segmented image
plt.figure(figsize=(10, 4))

plt.subplot(1, 3, 1)
plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
plt.title("Original Image")
plt.axis("off")

plt.subplot(1, 3, 2)
plt.plot(x, y, color="blue", label="Curve Fitting")
plt.xlabel("X")
plt.ylabel("Intensity")
plt.title("Polynomial Curve")
plt.legend()

plt.subplot(1, 3, 3)
plt.imshow(segmented_image, cmap="gray")
plt.title("Segmented Image")
plt.axis("off")

plt.tight_layout()
plt.show()
