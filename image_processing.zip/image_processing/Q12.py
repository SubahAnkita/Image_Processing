# 12. Write a program to color an image and perform read and write operation.
import cv2
from PIL import Image

# Specify the image path
image_path = r"C:\Users\tahia\OneDrive\Pictures\original.png"

# Read the image
image = cv2.imread(image_path)

# Perform colorization (replace with your colorization logic)
colorized_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)  # Example: converting to RGB

# Display the colorized image
cv2.imshow("Colorized Image", colorized_image)
cv2.waitKey(0)
cv2.destroyAllWindows()

# Specify the output path for the colorized image
output_path = r"C:\Users\tahia\OneDrive\Pictures\colorized.png"

# Save the colorized image
cv2.imwrite(output_path, colorized_image)

print("Colorized image saved successfully.")
