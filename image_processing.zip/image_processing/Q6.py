# 6. Write a program to implement high pass first order filter.
import numpy as np
import cv2
from PIL import Image

# Specify the image path
image_path = r"C:\Users\tahia\OneDrive\Pictures\original.png"

# Read the image
image = cv2.imread(image_path)

# Convert the image to grayscale
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Define the high-pass filter kernel
kernel = np.array([[0, -1, 0],
                   [-1, 5, -1],
                   [0, -1, 0]])

# Apply the high-pass filter using convolution
filtered_image = cv2.filter2D(gray_image, -1, kernel)

# Display the original and filtered images
cv2.imshow("Original Image", gray_image)
cv2.imshow("Filtered Image", filtered_image)
cv2.waitKey(0)
cv2.destroyAllWindows()
 