# 8. Write a program to show the non-linear filtering technique using edge
# detection.

import cv2
from PIL import Image
import numpy as np

# Specify the image path
image_path = r"C:\Users\tahia\OneDrive\Pictures\original.png"

# Read the image
image = cv2.imread(image_path)

# Convert the image to grayscale
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Apply Canny edge detection
edges = cv2.Canny(gray_image, 100, 200)

# Display the original and detected edges
cv2.imshow("Original Image", gray_image)
cv2.imshow("Detected Edges", edges)
cv2.waitKey(0)
cv2.destroyAllWindows()

