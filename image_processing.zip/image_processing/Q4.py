# 4. Write a program to extract the bit planes of a grayscale image.
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt

# Specify the image path
image_path = r"C:\Users\tahia\OneDrive\Pictures\original.png"

# Read the grayscale image
gray_image = Image.open(image_path).convert("L")

# Convert the image to a NumPy array
gray_array = np.array(gray_image)

# Extract the bit planes
bit_planes = []
for i in range(8):
    bit_plane = (gray_array >> i) & 1
    bit_planes.append(bit_plane)

# Display the bit planes
fig, axes = plt.subplots(2, 4, figsize=(12, 6))
axes = axes.flatten()

for i in range(8):
    axes[i].imshow(bit_planes[i], cmap='gray')
    axes[i].set_title(f"Bit Plane {i}")
    axes[i].axis('off')

plt.tight_layout()
plt.show()
